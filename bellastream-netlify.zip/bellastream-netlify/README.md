# 🎬 BELLASTREAM

**Stream Unlimited Movies & Series in HD**

©2026 | Powered by Rodgers

---

## 🚀 Quick Deployment to Netlify

### Method 1: Drag & Drop (Easiest)
1. Go to [Netlify Drop](https://app.netlify.com/drop)
2. Drag the entire `bellastream-netlify` folder onto the page
3. Your site will be live in seconds!

### Method 2: Git Deployment
1. Create a new repository on GitHub
2. Upload all files from this folder to the repository
3. Go to [Netlify](https://app.netlify.com/)
4. Click "Add new site" → "Import an existing project"
5. Connect your GitHub repository
6. Deploy!

### Method 3: Netlify CLI
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Navigate to this folder
cd bellastream-netlify

# Deploy
netlify deploy --prod
```

---

## 📁 Project Structure

```
bellastream-netlify/
├── index.html          # Main HTML file
├── styles.css          # All styling
├── app.js              # Application logic
├── netlify.toml        # Netlify configuration
└── README.md           # This file
```

---

## ✨ Features

✅ **Search Functionality** - Real-time movie search  
✅ **Trending Movies** - Live trending content with viewer counts  
✅ **Multiple Genres** - 12+ organized categories  
✅ **Quality Selector** - 1080p, 720p, 480p, 360p options  
✅ **Favorites System** - Save your favorite movies locally  
✅ **Contact Buttons** - WhatsApp integration for Manager, CEO & Channel  
✅ **Responsive Design** - Works on mobile, tablet & desktop  
✅ **Video Player** - Integrated streaming player  
✅ **Professional UI** - Modern Netflix-style interface  

---

## 🔧 Configuration

### APIs Used
- **TMDB API**: Movie data, posters, ratings, descriptions
- **VidSrc.pro**: Video streaming embedding
- **VidSrc.xyz**: Backup streaming service

### Contact Information
The following WhatsApp contacts are configured:

- **Manager**: +254 755 660 053
- **CEO**: +92 344 0242439
- **Channel**: https://whatsapp.com/channel/0029VbBR3ib3LdQQlEG3vd1x

To change these, edit the `openWhatsApp()` function in `app.js`.

---

## 🎨 Customization

### Change Colors
Edit the CSS variables in `styles.css`:
```css
:root {
    --primary: #e50914;        /* Main red color */
    --secondary: #ffd700;      /* Gold accent */
    --dark: #0a0a0a;          /* Background */
}
```

### Change Branding
1. Update logo text in `index.html` (search for "BELLASTREAM")
2. Update footer copyright in `index.html` (search for "Powered by Rodgers")
3. Update page title in `<title>` tag

### Add More Features
The codebase is well-commented and organized. Key functions:
- `fetchTrending()` - Get trending movies
- `openPlayer()` - Open video player
- `toggleFavorite()` - Manage favorites
- `performSearch()` - Search movies

---

## 📱 Browser Support

✅ Chrome (recommended)  
✅ Firefox  
✅ Safari  
✅ Edge  
✅ Mobile browsers  

---

## 🔒 Privacy & Storage

- Favorites are stored locally in browser localStorage
- No user data is sent to external servers
- All movie data comes from TMDB API (legal & free)
- Streaming uses VidSrc embedding services

---

## 📞 Support

For issues or questions, contact:
- **Manager**: +254 755 660 053
- **CEO**: +92 344 0242439
- **Channel**: https://whatsapp.com/channel/0029VbBR3ib3LdQQlEG3vd1x

---

## 📄 License

©2026 BELLASTREAM. All rights reserved.

---

## 🎉 Enjoy BELLASTREAM!

Your premium streaming platform is ready to go. Deploy to Netlify and start streaming!